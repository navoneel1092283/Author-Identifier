<?php
//connect to the db
$server="localhost";
$user="root";
$pw="";
$db="ipl";
$connection=mysqli_connect($server,$user,$pw,$db);
?>