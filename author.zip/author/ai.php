<?php
	include 'vendor/autoload.php'; // ML
	include 'vendor_stop/autoload.php'; // stopwords
	//include 'vendor_stem/autoload.php'; // stemming

	//include "includes/dbconnect.php";
	
	use Phpml\Dataset\CsvDataset;
	use Phpml\CrossValidation\RandomSplit;
	use Phpml\Metric\Accuracy;
	//use Wamania\Snowball\French; //stemming
	use Phpml\FeatureExtraction\TokenCountVectorizer;
	use Phpml\Tokenization\WhitespaceTokenizer;
	use Phpml\Classification\DecisionTree;


	$dataset = new CsvDataset('author - Copy.csv',1, true);
	$dataset = new RandomSplit($dataset, 0.2, 2345);

	// train group
	$samples_train=$dataset->getTrainSamples();
	$labels_train=$dataset->getTrainLabels();
	//print_r($labels_train);

	// test group
	$samples_test=$dataset->getTestSamples();
	$actualLabels=$dataset->getTestLabels();

	//text processing
	$filter = new Axisofstevil\StopWords\Filter();

	
	for($i=0;$i<=207;$i++)
	{
		//removing stop words
		$samples_train[$i][0]=$filter->cleanText($samples_train[$i][0]);

		//removing punctuation marks
		$samples_train[$i][0] = preg_replace("/[^a-zA-Z 0-9]+/", " ", $samples_train[$i][0]);
		
		//stemming 
		//$samples_train[$i][0] = $stemmer->stem($samples_train[$i][0]);
		$data_train[$i] = $samples_train[$i][0];

		//$vectorizer_train->fit($samples_train[$i]);
		//$vectorizer_train->transform($samples_train[$i]);
	}

	
	for($i=0;$i<=51;$i++)
	{
		//removing stop words
		$samples_test[$i][0] = $filter->cleanText($samples_test[$i][0]);

		//removing punctuation marks
		$samples_test[$i][0] = preg_replace("/[^a-zA-Z 0-9]+/", " ", $samples_test[$i][0]);
		
		//stemming 
		//$samples_train[$i][0] = $stemmer->stem($samples_train[$i][0]);
		$data_test[$i] = $samples_test[$i][0];

		//$vectorizer_train->fit($samples_train[$i]);
		//$vectorizer_train->transform($samples_train[$i]);
	}
	

	$vectorizer = new TokenCountVectorizer(new WhitespaceTokenizer());

	$vectorizer->fit($data_train);
	$vectorizer->fit($data_test);

	$vectorizer->transform($data_train);
	$vectorizer->transform($data_test);
	//print_r($data_train[0]);

	//$classifier = new SVC(Kernel:: RBF, $cost = 100);
	$classifier = new DecisionTree($numClassifier=21);
	$classifier->train($data_train, $labels_train);
	//print_r($data_train);
	//$predictedTLabels=$classifier->predict($data_train);
	//$predictedLabels=$classifier->predict($data_test);
	//echo(Accuracy::score($labels_train, $predictedTLabels));
	//echo "<br>";
	//echo(Accuracy::score($actualLabels, $predictedLabels));
	//echo "<br>";
	//print_r($data_train[0]);
	/*$filepath = 'model';

	$modelManager = new ModelManager();
	//$modelManager->saveToFile($classifier, $filepath);

	// PREDICTION*/

	session_start();

	$text=$_POST['text'];

	$text=$filter->cleanText($text);
	$text = preg_replace("/[^a-zA-Z 0-9]+/", " ", $text);
	$tex[0]=$text;
	$vectorizer->fit($tex);
	$vectorizer->transform($tex);


	$predict = $classifier->predict($tex);
	if($predict[0]==1)
	{
		header('location: identify/index1.php');
	}
	else
	{
		header('location: identify/index2.php');
	}


?>